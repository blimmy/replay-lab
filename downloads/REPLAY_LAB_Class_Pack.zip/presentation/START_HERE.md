# REPLAY LAB presentation package

The business idea, slides and script have been changed to REPLAY LAB: co-designed, childhood-memory Squishy/Slime collections produced when pre-orders meet a viable batch threshold.

- 01_REPLAY_LAB_Presentation.pptx — editable deck, speaker notes, 12 video slides and one hidden appendix.
- 01_REPLAY_LAB_Presentation.pdf — stable PDF version.
- 02_REPLAY_LAB_Script.docx / .pdf — matching English five-minute script.
- 03_REPLAY_LAB_Trend_Canvas.pdf / .png — matching infographic.
- 04_Sources_and_Assumptions.md — sources, limits and labelled economics assumptions.
- previews/contact_sheet.jpg — review all slides.
- assets/pixel.ttf — install Press Start 2P if PowerPoint substitutes the title font. PDF exports already embed it.

Original fieldwork is still pending: replace slide 3 and its narration with your real findings before recording. Use the questionnaires in the sibling research folder. Demo votes and reservations are browser-local simulations, not evidence of real demand.

Rebuild with the existing venv: python source/build_replay.py. Slide 7 uses assets/website_workshop.png, captured from the actual demo. The narration targets 4:50 including credits; rehearse and check the final recording stays under 5:00.
