# REPLAY LAB presentation package

The business idea, slides and script have been changed to REPLAY LAB: co-designed, childhood-memory Squishy/Slime collections produced when pre-orders meet a viable batch threshold.

- 01_REPLAY_LAB_Presentation.pptx — professional visual edition: editable text, tables and diagrams, speaker notes, 18 presentation slides, with a 25-second order-demo video embedded on slide 11.
- 01_REPLAY_LAB_Presentation.pdf — stable PDF version.
- 02_REPLAY_LAB_Script.docx / .pdf — matching English eight-minute script, with one speaking page per slide.
- 03_REPLAY_LAB_Trend_Canvas.pdf / .png — matching infographic.
- 04_Sources_and_Assumptions.md — sources, limits and labelled economics assumptions.
- previews/contact_sheet.jpg — review all slides.
- assets/pixel.ttf — install Press Start 2P if PowerPoint substitutes the small pixel labels. PDF exports already embed it.

Slide 4 includes the informal market interview described by the presenter. Confirm the market name, date and interviewee role when available. Its English wording is a paraphrase; it supports an account of adult interest in trying toys, not measured growth, purchases or motives. Use the questionnaires for follow-up research. Demo votes and reservations remain simulations.

Rebuild with the existing venv: python source/build_replay.py. Slide 11 includes the recorded order-demo MP4; the PDF shows a poster and video link. The expanded narration targets 8:00 including the demo and spoken source slide. Read only SAY THIS on each slide’s script page; rehearse and check actual duration.
