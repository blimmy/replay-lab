# REPLAY LAB research pack

All instruments are in English. This folder contains no participant responses.

## Files

- 01_Consumer_Questionnaire.docx / .pdf: printable/editable questionnaire.
- 02_Fieldwork_and_Analysis_Kit.docx / .pdf: collection method, interview guide, blank observation and interview forms, analysis rules.
- survey.json: browser-readable questionnaire with stable fields.
- respondents_blank.csv, observations_blank.csv, interviews_blank.csv: header-only data sheets.

## Website integration

The schema instructions are the contract. Render sections in order. Check screening stops before progressing. Required questions are required only when visible. On export, remove answers for hidden questions. Enforce maxSelections and exclusiveValues for checkboxes. Do not export non-consenting or ineligible research responses.

The concept must appear after behaviour questions, but record prior_concept_exposure because the visitor may already have seen the demo. Store and export locally only. Tell the participant that no central submission occurs; an export must be voluntarily shared to become collected data.

## Field codebook

### Before we begin

**consent** — radio; required when visible

May your anonymous answers be used for this class project?

`yes` = Yes, I agree; `no` = No, I do not agree

End survey for: no

**adult** — radio; required when visible

Are you 18 or older?

`yes` = Yes; `no` = No; `prefer_not` = Prefer not to answer

End survey for: no, prefer_not

**employment** — radio; required when visible

Which best describes your current work situation?

`full_time` = Working full-time; `part_time` = Working part-time; `self_employed` = Self-employed / freelance; `working_student` = Studying and working; `not_working` = Not currently working; `prefer_not` = Prefer not to answer

End survey for: not_working, prefer_not

### Your experience before this concept

**prior_concept_exposure** — radio; required when visible

Before starting this survey, had you already seen the REPLAY LAB idea or website demo?

`yes` = Yes; `no` = No; `not_sure` = Not sure

**age_band** — radio; optional

Which age band are you in?

`18_24` = 18–24; `25_34` = 25–34; `35_44` = 35–44; `45_plus` = 45 or older; `prefer_not` = Prefer not to answer

**purchase_recency** — radio; required when visible

When did you last buy a Squishy or Slime?

`past_3_months` = Within the past 3 months; `4_to_12_months` = 4–12 months ago; `over_12_months` = More than 12 months ago; `never` = I have never bought either

**purchase_purpose** — radio; required when visible

What was the MAIN purpose of your most recent purchase?

`personal_use` = My own use / enjoyment; `collecting` = My collection / display; `gift` = A gift for someone else; `resale` = Resale / business stock; `other` = Another purpose; `not_sure` = Not sure / do not remember

Display condition: {"id": "purchase_recency", "values": ["past_3_months", "4_to_12_months", "over_12_months"]}

**purchase_trigger** — radio; required when visible

What first drew your attention to the item you most recently bought?

`social_review` = A social-media review or creator video; `social_ad` = A social-media advertisement; `friend` = A friend, family member or colleague; `store` = Seeing it in a shop / market; `search` = Searching for it myself; `existing_hobby` = An existing hobby / collection; `other` = Something else; `not_sure` = I do not remember

Display condition: {"id": "purchase_recency", "values": ["past_3_months", "4_to_12_months", "over_12_months"]}

**purchase_reasons** — checkbox; required when visible

Which reasons influenced that purchase? Choose up to TWO.

`feel` = I liked the feel / sensory experience; `appearance` = I liked its appearance; `relaxation` = I wanted something enjoyable for a break; `memory` = It reminded me of childhood; `collection` = I wanted to add to a collection; `social` = People I follow or know were interested in it; `gift` = Someone else wanted it; `resale` = I intended to resell it; `other` = Another reason; `not_sure` = I do not remember

Display condition: {"id": "purchase_recency", "values": ["past_3_months", "4_to_12_months", "over_12_months"]}

**childhood_experience** — radio; required when visible

Before adulthood, what was your experience of Squishy or Slime?

`owned` = I owned or played with it; `wanted` = I wanted it but did not own it; `knew_not_interested` = I knew about it but was not interested; `unfamiliar` = I was not familiar with it; `not_sure` = I do not remember

### Now consider the REPLAY LAB idea

**product_choice** — radio; required when visible

Which would you choose for this concept, if any?

`squishy` = Squishy; `slime` = Slime; `neither` = Neither; `not_sure` = Not sure

**purchase_interest** — radio; required when visible

How likely would you be to consider buying from this service?

`very_unlikely` = Very unlikely; `unlikely` = Unlikely; `neither` = Neither likely nor unlikely; `likely` = Likely; `very_likely` = Very likely; `not_sure` = Not enough information to decide

**valued_features** — checkbox; required when visible

Which features, if any, would matter most to you? Choose up to TWO.

`memory` = A design linked to a childhood memory; `choice` = Choosing colour and texture; `prototype` = Seeing a prototype before ordering; `low_batch` = Production only after enough orders; `quiet` = A quiet / unscented option; `price` = An affordable total price; `quality` = Clear material and care information; `none` = None of these; `other` = Something else

**max_price_thb** — number; optional

For the hypothetical item described below, what is the highest TOTAL price in THB you would consider paying?

Display condition: {"id": "product_choice", "values": ["squishy", "slime"]}

**main_hesitation** — textarea; optional

What would make you hesitate or decide not to buy?

### Optional: feedback on the demo

**tried_demo** — radio; optional

Have you tried creating or saving a design in the demo?

`yes` = Yes; `no` = No

**demo_ease** — radio; optional

How easy or difficult was it to create and save a design?

`very_difficult` = Very difficult; `difficult` = Difficult; `neutral` = Neither easy nor difficult; `easy` = Easy; `very_easy` = Very easy; `not_completed` = I could not finish / did not try saving

Display condition: {"id": "tried_demo", "values": ["yes"]}

**demo_change** — textarea; optional

What is one thing you would change about the demo?

Display condition: {"id": "tried_demo", "values": ["yes"]}

## Reporting limits

No claims of statistical representativeness, causal influence or product health benefits follow from this small convenience study. Stated intention, hypothetical budget, demo votes and simulated orders do not establish real demand. Never fill blanks with invented values.