# REPLAY LAB — sources and evidence notes

Prepared 29 October 2026. All presentation content is in English.

Original fieldwork is pending. Published reports support the signal; they are not the presenter’s own observations. No buyer statistics, interview quotes, customer testimonials or actual business results have been invented.

## S1 — Thai PBS World | 25 Jun 2026

[Viral ‘squishy’ and ‘slime’ craze drives Sampheng retail boom](https://www.thaipbsworld.com/economy/social-media-driven-%E2%80%98squishy%E2%80%99-and-%E2%80%98slime%E2%80%99-craze-sparks-retail-boom-at-sampheng-market)

Supports: Reports renewed squishy/slime demand at Sampheng, social-media discovery and a vendor’s account of young professionals fulfilling childhood wishes.

Limit: A reported local signal, not a representative survey or proof of continued growth in October 2026.

## S2 — Thairath English | 19 Jun 2026

[Squishy Toys Trend: Soft, Slow-Rebound Sensation—Why Theyre Popular and How to Buy Safely](https://en.thairath.co.th/scoop/interview/2940686)

Supports: Reporting from Mega Plaza adds a second location, sensory product attributes, nostalgia and social-media attention.

Limit: Its observed customers were mainly children and teens. It does not independently establish the working-adult segment.

## S3 — TrendWatching | Consumer Trend Canvas

[How to do a Consumer Trend Canvas | Example - ACCLIMATORS](https://www.trendwatching.com/toolbox/consumer-trend-canvas/examples/acclimators)

Supports: Framework for linking inspiration, basic needs, drivers and expectations to an innovation, audience and format.

Limit: Used as a method; the ACCLIMATORS climate topic is not evidence for this toy trend.

## S4 — OCPB | 30 Jun 2026

[Inspection of squishy toy sellers (English description of the original report)](https://www.ocpb.go.th/news_view_plan.php?nid=18044)

Supports: The agency reported incomplete product labels during an inspection at Mega Plaza.

Limit: Supports treating sourcing and product information as operational concerns; it does not show every squishy is unsafe.

## S5 — SquishTide | custom squishies

[Custom photo squishies](https://squishtide.com/)

Supports: Offers photo-based custom squishies, showing that customisation already exists.

Limit: A competitor example; no claim of global novelty or validated demand for REPLAY LAB.

## Business and economics

REPLAY LAB is a proposed co-designed collection business for early-career Thai adults, replacing the previous Desk Break Bar concept. Customers can choose from shared shapes and personal details; selected collections would be produced only when a viable minimum pre-order threshold is met. The demo does not accept money or place real orders.

Illustrative squishy economics: THB 349 base selling price − THB 199 variable cost = THB 150 contribution per unit. THB 4,500 fixed design/setup ÷ THB 150 = 30 units. The actual minimum batch must also satisfy supplier MOQ, shipping, rejected items, payment fees, refunds, tax and any omitted cost. All numbers are planning assumptions, not validated quotes or willingness to pay.

Demo catalogue assumptions: squishy THB 349; slime THB 299; medium size +50; large +100; garnish +20; gift sleeve +40; optional story-card text included. The 30-unit batch threshold is an illustrative proposal. Do not count local demo clicks as research or revenue.

## Differentiation

Custom squishies exist (S5). The proposed difference is the combination of shared Thai childhood memories, adult use, co-design and small-batch commitment. This is not proof of uniqueness or competitive advantage.

## Visuals

All pixel-art desk objects and diagrams are original editable geometric drawings. They depict childhood-memory themes, not farm scenery. No Stardew Valley art or branding is used. Press Start 2P is distributed with its license in assets/. Arial is used for body text.

## Demo URL

https://blimmy.github.io/replay-lab/

Deployment state is reported by the site owner. The presentation links to the intended demo; it does not itself verify publication.