# REPLAY LAB — 8-minute English presentation script

1,112 spoken words. 18 slides. Read only the text under SAY THIS. Times are rehearsal targets.

## Slide 1 — Good memories. Made tangible.

**Time: 0:00–0:20 (20 seconds)**

### SAY THIS

Hello everyone. Think about a toy you wanted as a child but never bought. What would it mean to buy it today, with your own money? That question is the starting point for REPLAY LAB: a proposed business connecting childhood memories with personalised squishies and slime.

*Presenter cue — do not read aloud: Open on the original product artwork and brand promise. It is concept art, not fieldwork.*

## Slide 2 — A revival worth investigating.

**Time: 0:20–0:45 (25 seconds)**

### SAY THIS

First, let us look at the signal behind this idea. Thai PBS World reported renewed interest in squishies and slime at Sampheng in June twenty twenty-six. Thairath also covered a revival at Mega Plaza. These reports give us a reason to investigate. However, they describe particular places and moments, rather than proving the size or future growth of the whole market.

*Presenter cue — do not read aloud: Compare the two dated sources. S1 supports the reported adult-return account; S2 supports the broader sensory-toy revival.*

## Slide 3 — The toy is familiar. The buyer’s situation has changed.

**Time: 0:45–1:10 (25 seconds)**

### SAY THIS

The interesting change is not simply that toys are popular again. It is that some buyers now have a different relationship with them. The Sampheng report includes a vendor’s account of working adults buying toys they wanted when they were younger. A childhood wish that once depended on their parents can now become a purchase they choose for themselves.

*Presenter cue — do not read aloud: Show the before/after buying context. These are analytical labels, not participant quotations. Cite S1.*

## Slide 4 — A promising signal. An evidence gap to close.

**Time: 1:10–1:35 (25 seconds)**

### SAY THIS

Before explaining the business, I want to separate published evidence from my own research. Original fieldwork is still pending, and the Mega Plaza report mainly observed children and teenagers. It does not independently confirm adult demand. My next step is to interview working adults about their actual purchases, before showing them REPLAY LAB, so the concept does not shape their initial answers.

*Presenter cue — do not read aloud: Replace this plan with actual dated observations, buyer counts and one consented quote before submission. Published news is not personal fieldwork.*

## Slide 5 — Design for a specific buyer.

**Time: 1:35–2:00 (25 seconds)**

### SAY THIS

Based on that signal, my proposed target is early-career Thai adults who buy toys for themselves, rather than for children. They might keep a small object on a desk, display it at home, or enjoy using it during a break. These are possible use situations to test. The key question is which memories and product features matter to this specific group.

*Presenter cue — do not read aloud: Identify the proposed target and use context. Do not describe this as a researched persona.*

## Slide 6 — Memory can change what a toy is worth.

**Time: 2:00–2:30 (30 seconds)**

### SAY THIS

The first consumer behaviour concept is emotional motivation. A familiar shape may remind someone of an after-school routine or a game they enjoyed. The texture may also be enjoyable on its own. Adult income then gives that person more freedom to choose. My interpretation is that memory, enjoyment and choice could work together. However, emotional meaning does not automatically mean customers will pay a higher price.

*Presenter cue — do not read aloud: Explain memory, enjoyment and choice as an interpretation to test. No medical benefit or price premium is established.*

## Slide 7 — Discovery gets attention. Meaning may explain the purchase.

**Time: 2:30–3:00 (30 seconds)**

### SAY THIS

The second concept is social influence. Online reviews can bring an old toy back into someone’s attention. Seeing other adults enjoy it may also make the purchase feel more acceptable. But discovery and motivation are different. A review could make someone notice a squishy, while a personal memory gives them a reason to choose it. We therefore need to ask both how they discovered the toy and why they actually bought it.

*Presenter cue — do not read aloud: Follow reported discovery, interpreted relevance and a real choice still to test. S1 supports the first stage.*

## Slide 8 — Bring a familiar memory into my everyday life.

**Time: 3:00–3:25 (25 seconds)**

### SAY THIS

These ideas lead to the proposed value: bring a familiar memory into everyday life. REPLAY LAB combines three benefits. Meaning comes from a childhood reference. Choice comes from personal details. Confidence would come from clear samples, prices and order terms. The business needs to test whether customers value this combination enough to choose it over an ordinary toy.

*Presenter cue — do not read aloud: Present the proposed customer job and the three benefits. This is a value hypothesis.*

## Slide 9 — A shared memory. A personal object.

**Time: 3:25–3:50 (25 seconds)**

### SAY THIS

Here are three starting concepts: a pencil-case squishy, a gamepad squishy and cloud slime. Each suggests a different childhood moment, such as school supplies, weekend games or a treat after school. These are proposed themes, not proven customer preferences. Starting with a small selection would let us test which theme connects with buyers before spending money on more designs.

*Presenter cue — do not read aloud: Show actual prototype artwork. The themes are proposed, not observed customer preferences. S2 supplies sensory-product context.*

## Slide 10 — Four choices. One personal object.

**Time: 3:50–4:15 (25 seconds)**

### SAY THIS

The website turns that idea into four design steps: shape, colour, feel and story. A customer chooses the product, changes its appearance, selects sensory preferences and adds a name or memory. For a desk, they might prefer quiet and unscented options. The screen demonstrates those choices, but it cannot prove the real texture or smell. Physical samples would still be essential.

*Presenter cue — do not read aloud: Follow the four studio steps. Explain that real textures and scents need supplier-made samples.*

## Slide 11 — From a memory to a viable batch.

**Time: 4:15–4:55 (40 seconds)**

### SAY THIS

Let me show how the prototype works, from design to a saved reservation.

First, choose a gamepad shape. Change its colour, then name it Saturday Save Point. Save the design and add it to the demo bag. Review the illustrative price and confirm that this is a simulation. After confirming, the reservation appears in the notebook. No payment is taken and no product is ordered.

A real launch would also need supplier checks and clear production or refund terms.

*Presenter cue — do not read aloud: 0–7 seconds: read the introduction with the poster visible. At 7 seconds, click the embedded 25-second MP4 and read the middle paragraph over it. Use the final 8 seconds for the closing paragraph. The full 40-second slide slot already includes the demo; do not add another 25 seconds. Use the standalone MP4 if your presentation application cannot play the embedded clip.*

## Slide 12 — Personal meaning. Manageable production.

**Time: 4:55–5:20 (25 seconds)**

### SAY THIS

This raises an important business question: how can we offer personal meaning without making every item completely from scratch? My proposal uses shared shapes within a collection, while customers choose selected details and memory cards. Custom squishies already exist, so I am not claiming global originality. The proposed difference is the combination of Thai childhood memories, adult use and customer participation.

*Presenter cue — do not read aloud: Compare shared recipe and personal details. S5 demonstrates existing custom squishies; do not claim global novelty.*

## Slide 13 — Sell the object. Keep the options focused.

**Time: 5:20–5:45 (25 seconds)**

### SAY THIS

Revenue would come from selling the products and a limited range of upgrades. In the demo, squishies start at three hundred forty-nine baht and slime at two hundred ninety-nine baht. Larger sizes, finishing details or gift sleeves add to the price. These are illustrative amounts. We still need supplier quotes and customer testing to find a price that works for both sides.

*Presenter cue — do not read aloud: Present sample catalogue prices and optional upgrades as assumptions. Actual delivery costs and product terms remain unconfirmed.*

## Slide 14 — Three risks. Three practical tests.

**Time: 5:45–6:20 (35 seconds)**

### SAY THIS

There are three main risks. First, customers may like the idea but choose a cheaper toy. We should compare prototypes at realistic prices. Second, too many options could create production problems, so we should limit the range and check samples. Third, nostalgia may lead to only one purchase. We need to understand repeat-use or gifting reasons. The OCPB report also highlights product-information concerns at some sellers, making supplier and label checks part of the proposed launch process.

*Presenter cue — do not read aloud: Use the risk/test/result table. S4 reports incomplete labels at some sellers; avoid generalising to all toys.*

## Slide 15 — Make the batch pay for itself.

**Time: 6:20–7:00 (40 seconds)**

### SAY THIS

Now let us look at the illustrative economics. If a squishy sells for three hundred forty-nine baht and its variable cost is one hundred ninety-nine, the contribution is one hundred fifty baht per unit. This is the amount available to cover fixed costs, not final profit. With four thousand five hundred baht in setup costs, thirty units would cover that setup amount. The actual threshold must also meet the supplier’s minimum and account for all relevant costs, including fees, defects and delivery.

*Presenter cue — do not read aloud: Follow the proportional price bar, then the setup/contribution calculation. All numbers require real quotes and demand validation.*

## Slide 16 — Ask. Observe. Then commit.

**Time: 7:00–7:25 (25 seconds)**

### SAY THIS

To test the idea, I would follow three stages. First, ask actual buyers about their recent purchases. Second, introduce the concept and compare reactions to a prototype at a viable price. Third, confirm supplier samples, costs and terms before testing real orders. The questionnaire supports this process, but positive answers alone do not prove demand. Website demo reservations are also not real sales.

*Presenter cue — do not read aloud: Show the sequence of behaviour research, concept testing and supplier/purchase validation. Keep demo clicks separate from fieldwork.*

## Slide 17 — Start small. Earn the next batch.

**Time: 7:25–7:50 (25 seconds)**

### SAY THIS

My recommendation is to begin with one collection and three decision rules. Customers must choose it at a viable price, product quality must be consistent, and confirmed orders must cover the batch. If those conditions fail, we should change the idea before expanding. REPLAY LAB offers a way to explore a childhood memory as a product, with evidence guiding what happens next.

*Presenter cue — do not read aloud: End with three pilot gates and the clickable prototype link.*

## Slide 18 — Sources & prototype

**Time: 7:50–8:00 (10 seconds)**

### SAY THIS

These are the sources and prototype behind the proposal. The supporting files include the questionnaire and assumptions. Thank you for listening.

*Presenter cue — do not read aloud: Keep the source card visible while saying the closing lines. No extra silent credit interval is needed; this ten-second slide is included in the eight minutes.*
