# REPLAY LAB order demo

REPLAY_LAB_Order_Demo.mp4 is a 25-second H.264 recording of the functioning prototype with English on-screen instructions. It is silent so the presenter can narrate over it.

Journey: choose gamepad → change colour → name the design → save → add to bag → review the illustrative total → confirm a simulated reservation → inspect the notebook.

The MP4 is embedded on slide 11. In PowerPoint Slide Show mode, click the video. Playback depends on the presentation application; the standalone MP4 is included as a fallback. PDF shows a poster and clickable video link. The 4:50 script already includes this clip, with narration spoken over it.

All activity is synthetic demo activity. No payment, delivery or production order occurred. The clip is not consumer research evidence.
