# REPLAY LAB — 18-slide presentation edition

Open presentation/01_REPLAY_LAB_Presentation.pptx. All 18 slides are part of the presentation. Slide 11 contains the 25-second embedded demo: click the video in Slide Show mode. If your viewer does not support playback, open video/REPLAY_LAB_Order_Demo.mp4 separately. The PDF contains a poster and a video link.

The English script targets 8:00 including narration OVER the demo and a spoken closing on slide 18. Each slide has a separate script page labelled SAY THIS. The MP4 has English on-screen instructions and no audio. Do not add its duration to the script timeline again. Rehearse and time your final recording.

Replace slide 4 and the matching narration with your own actual observations or interviews before submission. Research forms are included; no original findings have been invented. The website is a simulation with no real payment or order.

Live website: https://blimmy.github.io/replay-lab/
