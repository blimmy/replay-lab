# REPLAY LAB presentation package

The business idea, slides and script have been changed to REPLAY LAB: co-designed, childhood-memory Squishy/Slime collections produced when pre-orders meet a viable batch threshold.

- 01_REPLAY_LAB_Presentation.pptx — professional visual edition: editable text, tables and diagrams, speaker notes, 18 presentation slides, with a 25-second order-demo video embedded on slide 11.
- 01_REPLAY_LAB_Presentation.pdf — stable PDF version.
- 02_REPLAY_LAB_Script.docx / .pdf — matching English five-minute script.
- 03_REPLAY_LAB_Trend_Canvas.pdf / .png — matching infographic.
- 04_Sources_and_Assumptions.md — sources, limits and labelled economics assumptions.
- previews/contact_sheet.jpg — review all slides.
- assets/pixel.ttf — install Press Start 2P if PowerPoint substitutes the small pixel labels. PDF exports already embed it.

Original fieldwork is still pending: replace slide 4 and its narration with your real findings before recording. Use the questionnaires in the sibling research folder. Demo votes and reservations are browser-local simulations, not evidence of real demand.

Rebuild with the existing venv: python source/build_replay.py. Slide 11 includes the recorded order-demo MP4; the PDF shows a poster and video link. The narration targets 4:50 including credits; rehearse and check the final recording stays under 5:00.
